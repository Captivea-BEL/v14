This module is a component of the Avatax Exemption Integration with odoo app.

  * Export Exemption customer in Avatax
  * Export Exemptions for customer based on nexus region
  * Export Custom rules based on avatax nexus regions
  * Export Product Taxcodes to Avatax
